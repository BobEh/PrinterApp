﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace PrinterApp
{
    public partial class PrinterApp : ServiceBase
    {
        FileSystemWatcher fileSystemWatcher;
        public PrinterApp()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            fileSystemWatcher = new FileSystemWatcher("C:\\test")
            {
                EnableRaisingEvents = true,
                IncludeSubdirectories = false
            };
            fileSystemWatcher.Created += SendToPrinter;
        }

        private void SendToPrinter(object sender, FileSystemEventArgs e)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.Verb = "print";
            info.FileName = $"{e.FullPath}";
            info.CreateNoWindow = true;
            info.WindowStyle = ProcessWindowStyle.Hidden;

            Process p = new Process();
            p.StartInfo = info;
            p.Start();

            p.WaitForInputIdle();
            System.Threading.Thread.Sleep(3000);
            if (false == p.CloseMainWindow())
                p.Kill();
        }

        protected override void OnStop()
        {
        }
    }
}
